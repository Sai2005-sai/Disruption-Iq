const v = (name) => `rgb(var(--${name}) / <alpha-value>)`;

export default {
  darkMode: 'class',
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      colors: {
        canvas: v('canvas'),
        surface: v('surface'),
        'surface-2': v('surface-2'),
        line: v('line'),
        ink: v('ink'),
        'ink-2': v('ink-2'),
        muted: v('muted'),
        primary: v('primary'),
        'primary-fg': v('primary-fg'),
        navy: '#0F2A4A',
        sidebar: v('sidebar'),
        accent: v('accent'),
        'accent-ink': v('accent-ink'),
        info: v('info'),
        'info-ink': v('info-ink'),
        risk: {
          low: v('risk-low'),
          'low-ink': v('risk-low-ink'),
          moderate: v('risk-moderate'),
          'moderate-ink': v('risk-moderate-ink'),
          high: v('risk-high'),
          'high-ink': v('risk-high-ink'),
          critical: v('risk-critical'),
          'critical-ink': v('risk-critical-ink'),
        },
      },
      boxShadow: {
        card: '0 1px 2px rgb(15 23 42 / 0.04), 0 4px 16px -4px rgb(15 23 42 / 0.06)',
        pop: '0 16px 40px -12px rgb(15 23 42 / 0.25), 0 2px 6px rgb(15 23 42 / 0.06)',
      },
      transitionTimingFunction: {
        out: 'cubic-bezier(0.23, 1, 0.32, 1)',
      },
    },
  },
};
