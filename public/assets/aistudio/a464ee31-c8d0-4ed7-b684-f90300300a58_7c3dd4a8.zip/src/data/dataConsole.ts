export type IssueType = 'invalid' | 'duplicate' | 'conflicting';

export const validationSummary = { valid: 1184, invalid: 7, duplicate: 4, conflicting: 2 };

export const validationIssues: {row: number;record: string;type: IssueType;reason: string;}[] = [
{ row: 14, record: 'ORD-10533', type: 'invalid', reason: 'Missing required field: delivery_pincode' },
{ row: 27, record: 'SHP-7735', type: 'invalid', reason: 'eta "2026-13-02" is not a valid ISO date' },
{ row: 33, record: 'ORD-10541', type: 'invalid', reason: 'quantity must be a positive integer (got -4)' },
{ row: 41, record: 'ORD-10482', type: 'duplicate', reason: 'Duplicate of row 9 (same order_id + line_no)' },
{ row: 58, record: 'WH-CHN-01 / ICM-220', type: 'conflicting', reason: 'stock 38 conflicts with live count 35 (Warehouse Operator, 10:12)' },
{ row: 66, record: 'SHP-7731', type: 'conflicting', reason: 'eta 29 Oct conflicts with supplier notice AP-2210 (2 Nov)' },
{ row: 72, record: 'ORD-10477', type: 'duplicate', reason: 'Duplicate of row 12 (same order_id + line_no)' },
{ row: 90, record: 'SUP-APEX', type: 'invalid', reason: 'Unknown supplier_code "APX-01"' }];


export const webhookCarriers = ['TVS Freight', 'BlueDart', 'Delhivery', 'Maersk'];

export const scenarios = [
{
  id: 'scn-1',
  name: 'Scenario 1: Supplier delay → stock shortage',
  description: 'Apex Components Ltd delays SHP-7731 by 4 days, creating a 120-unit ICM-220 shortage at Chennai.',
  steps: [
  'Supplier notice AP-2210 ingested',
  'SHP-7731 ETA revised 29 Oct → 2 Nov',
  'WH-CHN-01 projected stock recalculated: −120 units',
  '6 orders re-scored · 2 Critical',
  'Alert ALT-3108 raised for classification'],

  to: '/impact'
},
{
  id: 'scn-2',
  name: 'Scenario 2: Carrier webhook delay',
  description: 'BlueDart posts shipment.delayed for AWB 77812045, adding 9 hours to linehaul.',
  steps: [
  'Webhook shipment.delayed received (signature verified)',
  'Idempotency key checked — first delivery',
  'AWB 77812045 ETA +9h applied',
  '2 P3 orders re-scored · Moderate',
  'Alert ALT-3107 raised and auto-classified Moderate'],

  to: '/alerts'
}];