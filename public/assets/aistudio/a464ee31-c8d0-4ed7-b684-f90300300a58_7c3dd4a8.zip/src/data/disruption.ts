import { Severity } from '../types/domain';

export const activeDisruption = {
  id: 'DIS-2041',
  caseId: 'RC-2041',
  alertId: 'ALT-3108',
  title: 'Supplier delay on SHP-7731',
  summary:
  'Supplier delay on SHP-7731 causes a 120-unit stock shortage at the Chennai warehouse, putting 6 customer orders at risk (2 Critical).',
  supplier: 'Apex Components Ltd',
  shipment: 'SHP-7731',
  warehouse: 'Chennai · WH-CHN-01',
  product: 'ICM-220 Industrial Control Module',
  shortage: 120,
  ordersAtRisk: 6,
  critical: 2,
  severity: 'Major' as Severity,
  detected: '29 Oct 2026, 09:18',
  delayDays: 4
};

export type TraceStatus = 'delayed' | 'at-risk' | 'ok';

export interface TraceNode {
  id: string;
  stage: string;
  title: string;
  subtitle: string;
  status: TraceStatus;
  metric: string;
  detail: string;
}

export const traceNodes: TraceNode[] = [
{
  id: 'supplier',
  stage: 'Supplier',
  title: 'Apex Components Ltd',
  subtitle: 'Hosur plant · PO-8806',
  status: 'delayed',
  metric: 'Production delayed 4 days',
  detail: 'Reflow oven failure on SMT line 3. Supplier-confirmed revised dispatch: 2 Nov, 08:00.'
},
{
  id: 'shipment',
  stage: 'Shipment',
  title: 'SHP-7731',
  subtitle: '200 × ICM-220 · Road freight',
  status: 'delayed',
  metric: 'ETA 29 Oct → 2 Nov',
  detail: 'Not dispatched. Carrier slot with TVS Freight released; 80 units earmarked for Chennai priority orders.'
},
{
  id: 'warehouse',
  stage: 'Warehouse',
  title: 'Chennai WH-CHN-01',
  subtitle: 'Ambattur Industrial Estate',
  status: 'at-risk',
  metric: '35 on hand · 155 needed',
  detail: 'Weekly replenishment relied on SHP-7731. Safety stock was consumed on 27 Oct.'
},
{
  id: 'stock',
  stage: 'Product stock',
  title: 'ICM-220',
  subtitle: 'Industrial Control Module',
  status: 'delayed',
  metric: '120 units short',
  detail: 'Shortage persists until replenishment, transfer, or alternate sourcing is executed.'
},
{
  id: 'orders',
  stage: 'Customer orders',
  title: '6 orders at risk',
  subtitle: '2 Critical · 2 High · 1 Moderate · 1 Low',
  status: 'delayed',
  metric: 'Earliest deadline in 18h',
  detail: 'ORD-10482 (Sundaram Motors) and ORD-10477 (Coastal Pharma) breach SLA first.'
}];


export const parallelChain = ['Nova Textiles', 'SHP-7745', 'Bengaluru WH-BLR-02', 'FAB-112 stock', '14 orders'];

export const affectedWarehouses = [
{ id: 'WH-CHN-01', name: 'Chennai · Ambattur', product: 'ICM-220', current: 35, required: 155, note: 'Primary impact' },
{ id: 'WH-HYD-03', name: 'Hyderabad · Shamshabad', product: 'ICM-220', current: 62, required: 90, note: 'Secondary — 30% of SHP-7731 routed here' },
{ id: 'WH-BLR-02', name: 'Bengaluru · Hoskote', product: 'ICM-220', current: 180, required: 60, note: 'Surplus — candidate transfer source' }];


export const aiSummary = {
  headline: 'A 4-day supplier delay leaves Chennai 120 units short of ICM-220 — 2 orders breach SLA within 26 hours.',
  body: 'Apex Components Ltd confirmed a production stoppage on SMT line 3, so SHP-7731 (200 units) will not dispatch until 2 Nov. Chennai WH-CHN-01 holds 35 units against 155 committed, leaving 6 customer orders exposed. Bengaluru WH-BLR-02 has 120 uncommitted units within a 6h 40m road transfer, which is the fastest path to full coverage.',
  bullets: [
  'Root cause verified against supplier notice and carrier slot release',
  'Hyderabad is secondarily affected (28 units short) but has 5+ days of buffer',
  'No customer-facing SLA breach yet — first breach projected 30 Oct, 06:00'],

  confidence: 0.91,
  sources: ['Supplier notice #AP-2210', 'TVS Freight webhook', 'WMS cycle count 10:12', 'OMS order book']
};