import { RecoveryOption } from '../types/domain';

export const recoveryOptions: RecoveryOption[] = [
{
  id: 'opt-reallocate',
  title: 'Reallocate stock from Bengaluru',
  summary: 'Move 120 uncommitted ICM-220 units from WH-BLR-02 to Chennai by road.',
  cost: 184000,
  timeSavedDays: 3.5,
  ordersCovered: 6,
  feasibility: { inventory: true, deadline: true, constraints: true },
  feasibilityNote: '120 free units verified · arrives 30 Oct 01:40, before first deadline',
  approvers: ['scm', 'procurement', 'parent_company'],
  remainingRisk: 'Low',
  recommended: true,
  pros: ['Covers all 6 orders including both Critical', 'Arrives 4h 20m before the earliest deadline', 'Uses parent-owned surplus — no new purchase'],
  cons: ['Needs three approvals including Parent Company', 'Leaves Bengaluru with 60 units (exactly its committed demand)']
},
{
  id: 'opt-expedite',
  title: 'Expedite shipment SHP-7731',
  summary: 'Pay Apex for a priority run and air-freight 80 units on 31 Oct.',
  cost: 320000,
  timeSavedDays: 2,
  ordersCovered: 4,
  feasibility: { inventory: true, deadline: false, constraints: true },
  feasibilityNote: 'Lands 31 Oct 11:00 — misses ORD-10482 and ORD-10477 deadlines',
  approvers: ['scm', 'procurement'],
  remainingRisk: 'High',
  pros: ['No dependency on other warehouses', 'Restores the original supply plan'],
  cons: ['Most expensive option', 'Both Critical orders still breach SLA', 'Depends on supplier hitting a revised date']
},
{
  id: 'opt-alt-supplier',
  title: 'Alternative supplier',
  summary: 'Source 120 units from Vertex Electro Parts, Pune, on a spot PO.',
  cost: 410000,
  timeSavedDays: 1.5,
  ordersCovered: 5,
  feasibility: { inventory: true, deadline: true, constraints: false },
  feasibilityNote: 'Vertex not yet qualified for ICM-220 (QA audit due 12 Nov)',
  approvers: ['scm', 'procurement'],
  remainingRisk: 'Moderate',
  pros: ['Independent of Apex recovery', 'Vertex has 91 supplier performance score'],
  cons: ['Fails supplier-qualification constraint', 'Highest unit cost (+38%)', 'ORD-10482 still at risk if Pune dispatch slips']
},
{
  id: 'opt-split',
  title: 'Split orders into multiple deliveries',
  summary: 'Ship the 35 units on hand now to P1 orders; balance follows SHP-7731.',
  cost: 62000,
  timeSavedDays: 1,
  ordersCovered: 3,
  feasibility: { inventory: true, deadline: true, constraints: true },
  feasibilityNote: 'Partial fulfilment accepted by 3 of 6 customer contracts',
  approvers: ['scm'],
  remainingRisk: 'Moderate',
  pros: ['Cheapest and fastest to start', 'Single approval'],
  cons: ['Only partial quantities for Critical orders', 'Extra delivery runs and handling']
},
{
  id: 'opt-transfer',
  title: 'Inter-warehouse transfer (Coimbatore + Puducherry)',
  summary: 'Consolidate 62 units from WH-CBE-04 and WH-PDY-05 into Chennai.',
  cost: 126000,
  timeSavedDays: 2.5,
  ordersCovered: 3,
  feasibility: { inventory: false, deadline: true, constraints: true },
  feasibilityNote: 'Only 62 of 120 units available across both sites',
  approvers: ['scm', 'parent_company'],
  remainingRisk: 'Moderate',
  pros: ['Both sites within 3–9h of Chennai', 'Moderate cost'],
  cons: ['Covers only about half the shortage', 'Two pickups to coordinate']
}];