import React from 'react';
import { useSearchParams } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import { platformUsers } from '../data/users';
import { PageHeader } from '../components/ui/PageHeader';
import { Tabs } from '../components/ui/Tabs';
import { UsersRoles } from '../components/admin/UsersRoles';
import { AuditTrail } from '../components/admin/AuditTrail';
import { DataQuality } from '../components/admin/DataQuality';

export function Admin() {
  const [params, setParams] = useSearchParams();
  const { audit } = useApp();
  const tab = params.get('tab') ?? 'users';

  return (
    <>
      <PageHeader title="Administration" description="Manage who can do what, review every recorded action, and monitor data quality." />
      <Tabs
        className="mb-6"
        value={tab}
        onChange={(id) => setParams({ tab: id })}
        tabs={[
        { id: 'users', label: 'Users & roles', count: platformUsers.length },
        { id: 'audit', label: 'Audit trail', count: audit.length },
        { id: 'quality', label: 'Data quality' }]
        } />
      
      {tab === 'users' && <UsersRoles />}
      {tab === 'audit' && <AuditTrail />}
      {tab === 'quality' && <DataQuality />}
    </>);

}