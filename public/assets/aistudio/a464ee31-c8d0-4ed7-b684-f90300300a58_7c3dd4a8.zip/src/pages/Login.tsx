import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ActivityIcon, ArrowRightIcon, MailIcon, LockIcon, FactoryIcon, ShipIcon, WarehouseIcon, UsersIcon } from 'lucide-react';
import { toast } from 'sonner';
import { useApp } from '../contexts/AppContext';
import { portals } from '../data/portals';
import { activeDisruption } from '../data/disruption';
import { internalRoles, roleMeta } from '../utils/roles';
import { Role } from '../types/domain';
import { Button } from '../components/ui/Button';
import { Field, inputClass } from '../components/ui/Field';

const chain = [
{ icon: FactoryIcon, label: 'Apex Components Ltd', note: 'Delayed 4 days' },
{ icon: ShipIcon, label: 'SHP-7731', note: 'Not dispatched' },
{ icon: WarehouseIcon, label: 'Chennai WH-CHN-01', note: '120 units short' },
{ icon: UsersIcon, label: '6 customer orders', note: '2 Critical' }];


export function Login() {
  const navigate = useNavigate();
  const { setRole } = useApp();
  const [email, setEmail] = useState('meera.iyer@swiftlane.in');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [demoRole, setDemoRole] = useState<Role>('scm');

  const enter = (r: Role) => {
    setRole(r);
    toast.success(`Signed in as ${roleMeta[r].label}`, { description: roleMeta[r].user.name });
    navigate(roleMeta[r].home);
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) return setError('Enter a valid work email address.');
    if (password.length < 6) return setError('Password must be at least 6 characters.');
    setError('');
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      enter('partner_admin');
    }, 900);
  };

  return (
    <div className="min-h-screen w-full bg-canvas lg:grid lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
      <aside className="hidden flex-col justify-between bg-navy p-10 text-white lg:flex xl:p-14">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent text-navy">
            <ActivityIcon className="h-5 w-5" strokeWidth={2.5} />
          </span>
          <span className="text-lg font-semibold tracking-tight">DisruptionIQ</span>
        </div>

        <div>
          <h1 className="max-w-md text-4xl font-semibold leading-tight tracking-tight xl:text-[44px]">
            From Delivery Delays to Recovery Plans
          </h1>
          <p className="mt-4 max-w-md text-[15px] leading-relaxed text-white/70">
            Detect disruptions across suppliers, carriers and field agents, trace their impact to every customer order, and approve a verified recovery plan.
          </p>

          <div className="mt-10 max-w-md rounded-xl border border-white/10 bg-white/5 p-5">
            <div className="flex items-center justify-between text-xs text-white/60">
              <span>Live incident · {activeDisruption.id}</span>
              <span className="rounded-full bg-risk-high/20 px-2 py-0.5 font-medium text-orange-200">Major</span>
            </div>
            <ol className="mt-4 space-y-3">
              {chain.map((c, i) =>
              <li key={c.label} className="flex items-center gap-3">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/10">
                    <c.icon className="h-4 w-4 text-white/80" aria-hidden />
                  </span>
                  <span className="flex-1 text-sm">{c.label}</span>
                  <span className={i === 3 ? 'text-xs font-medium text-red-300' : 'text-xs text-white/60'}>{c.note}</span>
                </li>
              )}
            </ol>
          </div>
        </div>

        <p className="text-xs text-white/45">© 2026 DisruptionIQ · Demo environment with synthetic data</p>
      </aside>

      <main className="flex flex-col items-center px-4 py-10 sm:px-8 lg:justify-center lg:py-12">
        <div className="mb-8 flex items-center gap-2.5 lg:hidden">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy text-accent">
            <ActivityIcon className="h-5 w-5" strokeWidth={2.5} />
          </span>
          <span>
            <span className="block text-lg font-semibold tracking-tight text-ink">DisruptionIQ</span>
            <span className="block text-xs text-muted">From Delivery Delays to Recovery Plans</span>
          </span>
        </div>

        <div className="w-full max-w-2xl">
          <div className="mx-auto w-full max-w-md">
            <h2 className="text-2xl font-semibold tracking-tight text-ink">Sign in</h2>
            <p className="mt-1 text-sm text-muted">Use your SwiftLane work account.</p>
            <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
              <Field label="Work email" htmlFor="email" required>
                <div className="relative">
                  <MailIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" aria-hidden />
                  <input id="email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className={`${inputClass} pl-9`} />
                </div>
              </Field>
              <Field label="Password" htmlFor="password" required>
                <div className="relative">
                  <LockIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" aria-hidden />
                  <input
                    id="password"
                    type="password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="At least 6 characters"
                    className={`${inputClass} pl-9`} />
                  
                </div>
              </Field>
              {error &&
              <p role="alert" className="rounded-lg bg-risk-critical/10 px-3 py-2 text-sm text-risk-critical-ink">
                  {error}
                </p>
              }
              <Button type="submit" className="w-full" loading={loading}>
                Sign in
              </Button>
            </form>
          </div>

          <div className="my-8 flex items-center gap-3 text-xs text-muted">
            <span className="h-px flex-1 bg-line" />
            or enter a portal
            <span className="h-px flex-1 bg-line" />
          </div>

          <ul className="grid gap-3 sm:grid-cols-2">
            {portals.map((p) =>
            <li key={p.role}>
                <button
                onClick={() => enter(p.role)}
                className="group flex h-full w-full items-start gap-3 rounded-xl border border-line bg-surface p-4 text-left shadow-card transition-[border-color,transform] duration-150 ease-out hover:border-accent/60 active:scale-[0.99]">
                
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/5 text-ink dark:bg-white/5">
                    <p.icon className="h-5 w-5" aria-hidden />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-semibold text-ink">{p.title}</span>
                    <span className="mt-0.5 block text-[13px] text-muted">{p.description}</span>
                  </span>
                  <ArrowRightIcon className="mt-1 h-4 w-4 shrink-0 text-muted transition-transform duration-150 group-hover:translate-x-0.5 group-hover:text-accent-ink" aria-hidden />
                </button>
              </li>
            )}
          </ul>

          <div className="mt-4 flex flex-col gap-3 rounded-xl border border-dashed border-line p-4 sm:flex-row sm:items-end">
            <div className="flex-1">
              <label htmlFor="demo-role" className="mb-1.5 block text-[13px] font-medium text-ink-2">
                Demo as internal role
              </label>
              <select id="demo-role" value={demoRole} onChange={(e) => setDemoRole(e.target.value as Role)} className={inputClass}>
                {internalRoles.map((r) =>
                <option key={r} value={r}>
                    {roleMeta[r].label} — {roleMeta[r].user.name}
                  </option>
                )}
              </select>
            </div>
            <Button variant="secondary" onClick={() => enter(demoRole)} icon={<ArrowRightIcon className="h-4 w-4" />}>
              Continue
            </Button>
          </div>
        </div>
      </main>
    </div>);

}