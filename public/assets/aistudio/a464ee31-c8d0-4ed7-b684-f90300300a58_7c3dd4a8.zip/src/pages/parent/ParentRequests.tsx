import React, { useState } from 'react';
import { ArrowLeftIcon, CheckIcon, XIcon, InboxIcon, PackageIcon, TruckIcon } from 'lucide-react';
import { toast } from 'sonner';
import { parentRequests } from '../../data/parentRequests';
import { ParentRequest, StockAvailability } from '../../types/domain';
import { useApp } from '../../contexts/AppContext';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { RiskBadge, StatusChip, Tone } from '../../components/ui/Badge';
import { PageHeader } from '../../components/ui/PageHeader';
import { Modal } from '../../components/ui/Modal';
import { Field, inputClass } from '../../components/ui/Field';
import { EmptyState } from '../../components/ui/EmptyState';
import { Segmented } from '../../components/ui/Tabs';
import { cn } from '../../utils/cn';

const availTone: Record<StockAvailability, Tone> = { Available: 'success', 'Partially Available': 'warning', Unavailable: 'danger' };
const statusTone: Record<ParentRequest['status'], Tone> = { Pending: 'info', Approved: 'success', Rejected: 'danger' };
type Box = 'Pending' | 'All';

export function ParentRequests() {
  const { workflow, decideStep, logAudit } = useApp();
  const [requests, setRequests] = useState<ParentRequest[]>(parentRequests);
  const [selectedId, setSelectedId] = useState<string | null>('REQ-551');
  const [mobileDetail, setMobileDetail] = useState(false);
  const [box, setBox] = useState<Box>('Pending');
  const [comment, setComment] = useState('');
  const [error, setError] = useState('');
  const [confirmReject, setConfirmReject] = useState(false);

  const list = requests.filter((r) => box === 'All' || r.status === 'Pending');
  const selected = requests.find((r) => r.id === selectedId) ?? null;

  const decide = (status: 'Approved' | 'Rejected') => {
    if (!selected) return;
    if (status === 'Rejected' && comment.trim().length < 8) {
      setError('A rejection needs a comment of at least 8 characters.');
      return;
    }
    setRequests((rs) => rs.map((r) => r.id === selected.id ? { ...r, status } : r));
    logAudit({ action: status === 'Approved' ? 'Approval' : 'Rejection', target: selected.id, reason: comment.trim() || 'No comment', before: 'Pending', after: status });
    const parentStep = workflow.steps.find((s) => s.status === 'current' && s.role === 'parent_company');
    if (selected.linkedCase === workflow.planId && parentStep && selected.type === 'Transfer approval') {
      decideStep(status === 'Approved' ? 'approve' : 'reject', comment.trim() || `${status} via ${selected.id}`);
    }
    toast[status === 'Approved' ? 'success' : 'error'](`${selected.id} ${status.toLowerCase()}`, { description: `SwiftLane notified · linked case ${selected.linkedCase}` });
    setComment('');
    setError('');
    setConfirmReject(false);
  };

  return (
    <>
      <PageHeader
        title="Partner requests"
        description="Stock confirmations and transfer approvals from SwiftLane Logistics. Kaveri Industries owns the inventory."
        meta={<StatusChip tone="info">{requests.filter((r) => r.status === 'Pending').length} pending</StatusChip>} />
      
      <div className="grid gap-6 lg:grid-cols-[360px_minmax(0,1fr)]">
        <Card className={cn('self-start', mobileDetail && 'hidden lg:block')}>
          <div className="flex items-center justify-between border-b border-line p-4">
            <h2 className="text-[15px] font-semibold text-ink">Inbox</h2>
            <Segmented<Box>
              label="Inbox filter"
              value={box}
              onChange={setBox}
              options={[
              { id: 'Pending', label: 'Pending' },
              { id: 'All', label: 'All' }]
              } />
            
          </div>
          {list.length === 0 ?
          <EmptyState icon={InboxIcon} title="Inbox zero" body="No pending requests from your delivery partner." /> :

          <ul className="divide-y divide-line">
              {list.map((r) =>
            <li key={r.id}>
                  <button
                onClick={() => {
                  setSelectedId(r.id);
                  setMobileDetail(true);
                  setComment('');
                  setError('');
                }}
                className={cn('w-full px-4 py-3.5 text-left transition-colors duration-150 hover:bg-surface-2', r.id === selectedId && 'bg-accent/5')}>
                
                    <div className="flex items-center justify-between gap-2 text-xs text-muted">
                      <span>
                        {r.id} · {r.type}
                      </span>
                      <span>{r.received}</span>
                    </div>
                    <p className={cn('mt-1 text-sm', r.status === 'Pending' ? 'font-medium text-ink' : 'text-ink-2')}>{r.title}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <RiskBadge level={r.priority} />
                      <StatusChip tone={statusTone[r.status]}>{r.status}</StatusChip>
                    </div>
                  </button>
                </li>
            )}
            </ul>
          }
        </Card>

        <div className={cn('min-w-0', !mobileDetail && 'hidden lg:block')}>
          {selected ?
          <Card className="p-5 lg:p-6">
              <button onClick={() => setMobileDetail(false)} className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted hover:text-ink lg:hidden">
                <ArrowLeftIcon className="h-4 w-4" /> Back to inbox
              </button>
              <nav aria-label="Breadcrumb" className="mb-2 text-[13px] text-muted">
                Parent portal / Requests / <span className="text-ink-2">{selected.id}</span>
              </nav>
              <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                <div>
                  <h2 className="text-xl font-semibold tracking-tight text-ink">{selected.title}</h2>
                  <p className="mt-1 text-sm text-muted">
                    From {selected.from} · {selected.received} · Case {selected.linkedCase}
                  </p>
                </div>
                <div className="flex gap-2">
                  <RiskBadge level={selected.priority} />
                  <StatusChip tone={statusTone[selected.status]}>{selected.status}</StatusChip>
                </div>
              </div>

              <div className="mt-6 grid gap-4 md:grid-cols-2">
                <section className="rounded-lg border border-line p-4">
                  <h3 className="flex items-center gap-2 text-sm font-semibold text-ink">
                    <PackageIcon className="h-4 w-4 text-muted" aria-hidden /> Order
                  </h3>
                  <dl className="mt-3 grid grid-cols-2 gap-y-2 text-sm">
                    <dt className="text-muted">Order</dt>
                    <dd className="text-ink">{selected.order.id}</dd>
                    <dt className="text-muted">Customer</dt>
                    <dd className="text-ink">{selected.order.customer}</dd>
                    <dt className="text-muted">Deadline</dt>
                    <dd className="text-ink">{selected.order.deadline}</dd>
                    <dt className="text-muted">Order value</dt>
                    <dd className="tabular-nums text-ink">{selected.order.value}</dd>
                  </dl>
                </section>
                <section className="rounded-lg border border-line p-4">
                  <h3 className="flex items-center gap-2 text-sm font-semibold text-ink">
                    <TruckIcon className="h-4 w-4 text-muted" aria-hidden /> Shipment
                  </h3>
                  <dl className="mt-3 grid grid-cols-2 gap-y-2 text-sm">
                    <dt className="text-muted">Shipment</dt>
                    <dd className="text-ink">{selected.shipment.id}</dd>
                    <dt className="text-muted">Route</dt>
                    <dd className="text-ink">
                      {selected.shipment.origin} → {selected.shipment.destination}
                    </dd>
                    <dt className="text-muted">Status</dt>
                    <dd className="text-ink">{selected.shipment.status}</dd>
                    <dt className="text-muted">Mode</dt>
                    <dd className="text-ink">{selected.shipment.mode}</dd>
                  </dl>
                </section>
              </div>

              <section className="mt-6">
                <h3 className="text-sm font-semibold text-ink">Products</h3>
                <div className="mt-3 overflow-x-auto rounded-lg border border-line">
                  <table className="w-full min-w-[520px] text-sm">
                    <thead>
                      <tr className="border-b border-line bg-surface-2/60 text-left text-xs text-muted">
                        <th className="px-4 py-2.5 font-medium">Product</th>
                        <th className="px-4 py-2.5 text-right font-medium">Requested</th>
                        <th className="px-4 py-2.5 text-right font-medium">On hand</th>
                        <th className="px-4 py-2.5 font-medium">Stock status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-line">
                      {selected.products.map((p) =>
                    <tr key={p.sku}>
                          <td className="px-4 py-3">
                            <p className="font-medium text-ink">{p.name}</p>
                            <p className="text-xs text-muted">
                              {p.sku} · {p.location}
                            </p>
                          </td>
                          <td className="px-4 py-3 text-right tabular-nums text-ink">{p.requested}</td>
                          <td className="px-4 py-3 text-right tabular-nums text-ink">{p.onHand}</td>
                          <td className="px-4 py-3">
                            <StatusChip tone={availTone[p.availability]} dot>
                              {p.availability}
                            </StatusChip>
                          </td>
                        </tr>
                    )}
                    </tbody>
                  </table>
                </div>
                <p className="mt-2 text-xs text-muted">{selected.note}</p>
              </section>

              {selected.status === 'Pending' ?
            <section className="mt-6 border-t border-line pt-5">
                  <Field label="Comment to SwiftLane" htmlFor="parent-comment" error={error} hint="Required when rejecting">
                    <textarea id="parent-comment" rows={3} value={comment} onChange={(e) => setComment(e.target.value)} className={inputClass} placeholder="e.g. Approved — keep 60 units at Bengaluru for ORD-10520" />
                  </Field>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Button icon={<CheckIcon className="h-4 w-4" />} onClick={() => decide('Approved')}>
                      Approve
                    </Button>
                    <Button variant="secondary" className="text-risk-critical-ink" icon={<XIcon className="h-4 w-4" />} onClick={() => setConfirmReject(true)}>
                      Reject
                    </Button>
                  </div>
                </section> :

            <p className="mt-6 rounded-lg bg-surface-2 px-4 py-3 text-sm text-ink-2">
                  This request was {selected.status.toLowerCase()}. Decisions are final and recorded in the audit trail.
                </p>
            }
            </Card> :

          <Card>
              <EmptyState icon={InboxIcon} title="Select a request" body="Pick a request from the inbox to inspect order, shipment and stock details." />
            </Card>
          }
        </div>
      </div>

      <Modal
        open={confirmReject}
        onClose={() => setConfirmReject(false)}
        title={`Reject ${selected?.id ?? ''}?`}
        description="SwiftLane will need to choose another recovery path."
        footer={
        <>
            <Button variant="secondary" onClick={() => setConfirmReject(false)}>
              Cancel
            </Button>
            <Button variant="danger" onClick={() => decide('Rejected')}>
              Reject request
            </Button>
          </>
        }>
        
        <Field label="Reason" htmlFor="reject-comment" required error={error}>
          <textarea id="reject-comment" rows={3} value={comment} onChange={(e) => setComment(e.target.value)} className={inputClass} placeholder="Why can’t this be approved?" />
        </Field>
      </Modal>
    </>);

}