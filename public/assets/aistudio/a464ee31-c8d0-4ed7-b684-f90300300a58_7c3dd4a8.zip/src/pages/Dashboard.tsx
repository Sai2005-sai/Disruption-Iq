import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowRightIcon, ArrowUpRightIcon } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useApp } from '../contexts/AppContext';
import { kpis, severityChart, supplierScores, recoveryTrend, pendingApprovals, initialFeed, feedPool, FeedAlert } from '../data/dashboard';
import { activeDisruption } from '../data/disruption';
import { useSimulatedLoading } from '../hooks/useSimulatedLoading';
import { chartTheme } from '../utils/chartTheme';
import { riskHex, riskStyles } from '../utils/risk';
import { formatINR } from '../utils/format';
import { Card, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { RiskBadge } from '../components/ui/Badge';
import { PageHeader } from '../components/ui/PageHeader';
import { Skeleton } from '../components/ui/Skeleton';
import { cn } from '../utils/cn';

function scoreColor(score: number): string {
  if (score >= 85) return riskHex.Low;
  if (score >= 70) return riskHex.Moderate;
  if (score >= 55) return riskHex.High;
  return riskHex.Critical;
}

export function Dashboard() {
  const { dark, workflow } = useApp();
  const navigate = useNavigate();
  const loading = useSimulatedLoading(700);
  const t = chartTheme(dark);
  const [feed, setFeed] = useState<FeedAlert[]>(initialFeed);
  const poolIdx = useRef(0);

  useEffect(() => {
    const timer = setInterval(() => {
      const item = feedPool[poolIdx.current % feedPool.length];
      poolIdx.current += 1;
      const now = new Date();
      setFeed((f) => [{ ...item, id: `F-${Date.now()}`, time: `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}` }, ...f].slice(0, 6));
    }, 9000);
    return () => clearInterval(timer);
  }, []);

  const approvals = [
  ...(workflow.state === 'in_review' ?
  [{ id: workflow.planId, title: workflow.optionTitle ?? '', amount: formatINR(workflow.cost), approver: 'In approval chain', age: 'Just now' }] :
  []),
  ...pendingApprovals];


  return (
    <>
      <PageHeader
        title="Operations overview"
        description="SwiftLane Logistics · South region · updated live"
        actions={
        <Button variant="secondary" onClick={() => navigate('/alerts')}>
            View all alerts
          </Button>
        } />
      

      <Card className="mb-6 overflow-hidden">
        <div className="flex flex-col gap-5 p-5 md:flex-row md:items-center md:justify-between lg:p-6">
          <div className="flex gap-4">
            <span className="mt-1 h-10 w-1 shrink-0 rounded-full bg-risk-high" aria-hidden />
            <div>
              <div className="flex flex-wrap items-center gap-2 text-[13px] text-muted">
                <span className="font-medium text-ink-2">{activeDisruption.id}</span>
                <RiskBadge level="High" label="Major" />
                <span>Detected {activeDisruption.detected}</span>
              </div>
              <h2 className="mt-1.5 text-lg font-semibold leading-snug text-ink lg:text-xl">{activeDisruption.summary}</h2>
            </div>
          </div>
          <div className="flex shrink-0 flex-wrap gap-2">
            <Button variant="secondary" onClick={() => navigate('/orders')}>
              Order risk
            </Button>
            <Button icon={<ArrowRightIcon className="h-4 w-4" />} onClick={() => navigate('/impact')}>
              Trace impact
            </Button>
          </div>
        </div>
      </Card>

      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        {kpis.map((k) =>
        <Link
          key={k.id}
          to={k.to}
          className={cn(
            'group rounded-xl border bg-surface p-4 shadow-card transition-[border-color] duration-150 hover:border-accent/50',
            k.tone === 'critical' ? 'border-risk-critical/40' : 'border-line'
          )}>
          
            {loading ?
          <div className="space-y-2">
                <Skeleton className="h-3 w-20" />
                <Skeleton className="h-7 w-14" />
                <Skeleton className="h-3 w-24" />
              </div> :

          <>
                <p className="flex items-center justify-between text-[13px] text-muted">
                  {k.label}
                  <ArrowUpRightIcon className="h-3.5 w-3.5 opacity-0 transition-opacity duration-150 group-hover:opacity-100" aria-hidden />
                </p>
                <p className={cn('mt-1 text-2xl font-semibold tabular-nums tracking-tight', k.tone === 'critical' ? 'text-risk-critical-ink' : 'text-ink')}>{k.value}</p>
                <p className={cn('mt-0.5 text-xs', k.tone === 'positive' ? 'text-risk-low-ink' : 'text-muted')}>{k.delta}</p>
              </>
          }
          </Link>
        )}
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="min-w-0 space-y-6 xl:col-span-2">
          <Card>
            <CardHeader title="Recovery progress" description="Share of at-risk orders with an executed recovery plan vs. target" />
            <div className="h-64 px-2 pb-4 pt-4">
              {loading ?
              <Skeleton className="mx-3 h-full" /> :

              <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={recoveryTrend} margin={{ top: 8, right: 16, left: -12, bottom: 0 }}>
                    <CartesianGrid stroke={t.grid} vertical={false} />
                    <XAxis dataKey="day" tick={{ fill: t.tick, fontSize: 12 }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: t.tick, fontSize: 12 }} axisLine={false} tickLine={false} unit="%" domain={[0, 100]} />
                    <Tooltip contentStyle={t.tooltip} />
                    <Line type="monotone" dataKey="target" name="Target" stroke={t.tick} strokeDasharray="4 4" strokeWidth={1.5} dot={false} />
                    <Line type="monotone" dataKey="progress" name="Progress" stroke={t.accent} strokeWidth={2.5} dot={{ r: 3, fill: t.accent }} activeDot={{ r: 5 }} />
                  </LineChart>
                </ResponsiveContainer>
              }
            </div>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader title="Disruptions by severity" description="Last 7 days · 21 total" />
              <div className="h-56 px-2 pb-4 pt-4">
                {loading ?
                <Skeleton className="mx-3 h-full" /> :

                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={severityChart} margin={{ top: 8, right: 12, left: -20, bottom: 0 }}>
                      <CartesianGrid stroke={t.grid} vertical={false} />
                      <XAxis dataKey="name" tick={{ fill: t.tick, fontSize: 12 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: t.tick, fontSize: 12 }} axisLine={false} tickLine={false} allowDecimals={false} />
                      <Tooltip contentStyle={t.tooltip} cursor={{ fill: t.cursor }} />
                      <Bar dataKey="value" name="Disruptions" radius={[6, 6, 0, 0]} maxBarSize={44}>
                        {severityChart.map((s) =>
                      <Cell key={s.name} fill={riskHex[s.risk]} />
                      )}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                }
              </div>
            </Card>
            <Card>
              <CardHeader title="Supplier performance" description="On-time, quality and notice score (0–100)" />
              <div className="h-56 px-2 pb-4 pt-4">
                {loading ?
                <Skeleton className="mx-3 h-full" /> :

                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={supplierScores} layout="vertical" margin={{ top: 0, right: 20, left: 8, bottom: 0 }}>
                      <CartesianGrid stroke={t.grid} horizontal={false} />
                      <XAxis type="number" domain={[0, 100]} tick={{ fill: t.tick, fontSize: 12 }} axisLine={false} tickLine={false} />
                      <YAxis type="category" dataKey="supplier" width={112} tick={{ fill: t.tick, fontSize: 12 }} axisLine={false} tickLine={false} />
                      <Tooltip contentStyle={t.tooltip} cursor={{ fill: t.cursor }} />
                      <Bar dataKey="score" name="Score" radius={[0, 6, 6, 0]} maxBarSize={18}>
                        {supplierScores.map((s) =>
                      <Cell key={s.supplier} fill={scoreColor(s.score)} />
                      )}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                }
              </div>
            </Card>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader
              title="Live alerts"
              action={
              <span className="inline-flex items-center gap-1.5 text-xs text-muted">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-60" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-accent" />
                  </span>
                  Streaming
                </span>
              } />
            
            <ul className="mt-3 divide-y divide-line">
              <AnimatePresence initial={false}>
                {feed.map((a) =>
                <motion.li
                  key={a.id}
                  layout
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}>
                  
                    <Link to="/alerts" className="flex gap-3 px-5 py-3 transition-colors duration-150 hover:bg-surface-2">
                      <span className={cn('mt-1.5 h-2 w-2 shrink-0 rounded-full', riskStyles[a.risk].dot)} aria-label={a.risk} />
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm text-ink">{a.title}</span>
                        <span className="block text-xs text-muted">{a.source}</span>
                      </span>
                      <span className="shrink-0 text-xs tabular-nums text-muted">{a.time}</span>
                    </Link>
                  </motion.li>
                )}
              </AnimatePresence>
            </ul>
          </Card>

          <Card>
            <CardHeader
              title="Pending approvals"
              action={
              <Link to="/approvals" className="text-[13px] font-medium text-accent-ink hover:underline">
                  Open
                </Link>
              } />
            
            <ul className="mt-3 divide-y divide-line pb-1">
              {approvals.map((p) =>
              <li key={p.id}>
                  <Link to="/approvals" className="flex items-start justify-between gap-3 px-5 py-3 transition-colors duration-150 hover:bg-surface-2">
                    <span className="min-w-0">
                      <span className="block text-sm text-ink">{p.title}</span>
                      <span className="block text-xs text-muted">
                        {p.id} · {p.approver} · {p.age}
                      </span>
                    </span>
                    <span className="shrink-0 text-sm font-medium tabular-nums text-ink">{p.amount}</span>
                  </Link>
                </li>
              )}
            </ul>
          </Card>
        </div>
      </div>
    </>);

}