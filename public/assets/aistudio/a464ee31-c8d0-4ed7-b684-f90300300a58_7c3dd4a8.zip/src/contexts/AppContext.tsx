import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  AppNotification,
  AuditEntry,
  RecoveryOption,
  Role,
  Workflow,
  WorkflowDecision } from
'../types/domain';
import { roleMeta, RoleUser } from '../utils/roles';
import { seedNotifications } from '../data/notifications';
import { seedAudit } from '../data/audit';
import { formatINR, nowStamp } from '../utils/format';

type NewAudit = Omit<AuditEntry, 'id' | 'timestamp' | 'user' | 'role'>;
type NewNotification = Omit<AppNotification, 'id' | 'read' | 'time'>;

interface AppContextValue {
  role: Role;
  setRole: (r: Role) => void;
  user: RoleUser;
  dark: boolean;
  toggleDark: () => void;
  notifications: AppNotification[];
  markRead: (id: string) => void;
  markAllRead: () => void;
  pushNotification: (n: NewNotification) => void;
  audit: AuditEntry[];
  logAudit: (e: NewAudit) => void;
  workflow: Workflow;
  selectOption: (option: RecoveryOption) => void;
  decideStep: (decision: WorkflowDecision, comment: string, change?: {quantity: number;dispatchMode: string;}) => void;
  markStale: (reason: string) => void;
  executePlan: () => void;
  resetWorkflow: () => void;
}

const emptyWorkflow: Workflow = {
  planId: 'RC-2041',
  optionId: null,
  optionTitle: null,
  cost: 0,
  quantity: 120,
  dispatchMode: 'Standard road freight',
  createdBy: null,
  createdByRole: null,
  createdAt: null,
  steps: [],
  state: 'none',
  stale: false,
  executedAt: null
};

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: {children: React.ReactNode;}) {
  const [role, setRole] = useState<Role>('partner_admin');
  const [dark, setDark] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>(seedNotifications);
  const [audit, setAudit] = useState<AuditEntry[]>(seedAudit);
  const [workflow, setWorkflow] = useState<Workflow>(emptyWorkflow);
  const user = roleMeta[role].user;

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
  }, [dark]);

  const logAudit = useCallback(
    (e: NewAudit) =>
    setAudit((prev) => [
    { ...e, id: `AUD-${9001 + prev.length}`, timestamp: nowStamp(), user: user.name, role: roleMeta[role].label },
    ...prev]
    ),
    [role, user.name]
  );

  const pushNotification = useCallback(
    (n: NewNotification) =>
    setNotifications((prev) => [{ ...n, id: `N-${Date.now()}-${prev.length}`, read: false, time: 'Just now' }, ...prev]),
    []
  );

  const markRead = useCallback(
    (id: string) => setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, read: true } : n)),
    []
  );
  const markAllRead = useCallback(() => setNotifications((prev) => prev.map((n) => ({ ...n, read: true }))), []);

  const selectOption = useCallback(
    (option: RecoveryOption) => {
      setWorkflow({
        ...emptyWorkflow,
        optionId: option.id,
        optionTitle: option.title,
        cost: option.cost,
        createdBy: user.name,
        createdByRole: role,
        createdAt: nowStamp(),
        steps: option.approvers.map((r, i) => ({ role: r, status: i === 0 ? 'current' : 'waiting' })),
        state: 'in_review'
      });
      logAudit({
        action: 'Plan created',
        target: 'RC-2041',
        reason: `Selected recovery option "${option.title}"`,
        after: `${option.title} · ${formatINR(option.cost)}`
      });
      pushNotification({ title: 'Plan sent for approval', body: `RC-2041 · ${option.title}`, type: 'approval', to: '/approvals' });
    },
    [user.name, role, logAudit, pushNotification]
  );

  const decideStep = useCallback(
    (decision: WorkflowDecision, comment: string, change?: {quantity: number;dispatchMode: string;}) => {
      const idx = workflow.steps.findIndex((s) => s.status === 'current');
      if (idx < 0) return;
      const steps = workflow.steps.map((s, i) =>
      i === idx ?
      {
        ...s,
        status: decision === 'approve' ? 'approved' as const : decision === 'modify' ? 'modified' as const : 'rejected' as const,
        by: user.name,
        at: nowStamp(),
        comment
      } :
      s
      );
      let state: Workflow['state'] = workflow.state;
      if (decision === 'reject') state = 'rejected';else
      if (idx + 1 < steps.length) steps[idx + 1] = { ...steps[idx + 1], status: 'current' };else
      state = 'approved';

      const before = `${workflow.quantity} units · ${workflow.dispatchMode}`;
      setWorkflow({
        ...workflow,
        steps,
        state,
        stale: state === 'approved' ? false : workflow.stale,
        quantity: change?.quantity ?? workflow.quantity,
        dispatchMode: change?.dispatchMode ?? workflow.dispatchMode
      });
      logAudit({
        action: decision === 'approve' ? 'Approval' : decision === 'reject' ? 'Rejection' : 'Modification',
        target: 'RC-2041',
        reason: comment || 'No comment',
        before: change ? before : undefined,
        after: change ? `${change.quantity} units · ${change.dispatchMode}` : undefined
      });
      if (state === 'approved') {
        pushNotification({ title: 'RC-2041 fully approved', body: 'Ready for simulated execution', type: 'approval', to: '/approvals' });
      }
    },
    [workflow, user.name, logAudit, pushNotification]
  );

  const markStale = useCallback(
    (reason: string) => {
      setWorkflow((w) => ({
        ...w,
        state: 'in_review',
        stale: true,
        steps: w.steps.map((s, i) => ({ role: s.role, status: i === 0 ? 'current' : 'waiting' }))
      }));
      logAudit({ action: 'Execution', target: 'RC-2041', reason, before: 'Approved', after: 'Stale · re-approval required' });
    },
    [logAudit]
  );

  const executePlan = useCallback(() => {
    setWorkflow((w) => ({ ...w, state: 'executed', executedAt: nowStamp() }));
    logAudit({
      action: 'Execution',
      target: 'RC-2041',
      reason: 'Simulated execution passed all revalidation checks',
      before: 'Approved',
      after: 'Executed (simulation)'
    });
    pushNotification({ title: 'RC-2041 executed (simulation)', body: '6 customer ETAs updated', type: 'approval', to: '/approvals' });
  }, [logAudit, pushNotification]);

  const resetWorkflow = useCallback(() => setWorkflow(emptyWorkflow), []);

  const value = useMemo<AppContextValue>(
    () => ({
      role,
      setRole,
      user,
      dark,
      toggleDark: () => setDark((d) => !d),
      notifications,
      markRead,
      markAllRead,
      pushNotification,
      audit,
      logAudit,
      workflow,
      selectOption,
      decideStep,
      markStale,
      executePlan,
      resetWorkflow
    }),
    [role, user, dark, notifications, markRead, markAllRead, pushNotification, audit, logAudit, workflow, selectOption, decideStep, markStale, executePlan, resetWorkflow]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}