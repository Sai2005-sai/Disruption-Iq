import React, { useEffect, useRef, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { RestrictedState } from './RestrictedState';
import { useApp } from '../../contexts/AppContext';
import { canAccess } from '../../utils/roles';

export function AppShell() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { role } = useApp();
  const location = useLocation();
  const mainRef = useRef<HTMLElement>(null);

  useEffect(() => {
    setMobileOpen(false);
    mainRef.current?.scrollTo({ top: 0 });
  }, [location.pathname]);

  const allowed = canAccess(role, location.pathname);

  return (
    <div className="flex h-screen w-full overflow-hidden bg-canvas">
      <Sidebar mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar onMenu={() => setMobileOpen(true)} />
        <main ref={mainRef} id="main" className="flex-1 overflow-y-auto">
          <div className="mx-auto w-full max-w-[1440px] px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
            {allowed ? <Outlet /> : <RestrictedState path={location.pathname} />}
          </div>
        </main>
      </div>
    </div>);

}