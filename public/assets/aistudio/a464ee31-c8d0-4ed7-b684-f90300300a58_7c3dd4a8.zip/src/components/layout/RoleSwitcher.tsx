import React, { useCallback, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CheckIcon, ChevronDownIcon, ShieldIcon } from 'lucide-react';
import { toast } from 'sonner';
import { useApp } from '../../contexts/AppContext';
import { canAccess, internalRoles, portalRoles, roleMeta } from '../../utils/roles';
import { Role } from '../../types/domain';
import { useClickOutside } from '../../hooks/useClickOutside';
import { DropdownPanel } from '../ui/DropdownPanel';
import { cn } from '../../utils/cn';

export function RoleSwitcher() {
  const { role, setRole } = useApp();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const close = useCallback(() => setOpen(false), []);
  useClickOutside(ref, close, open);

  const choose = (r: Role) => {
    setRole(r);
    setOpen(false);
    toast.success(`Now viewing as ${roleMeta[r].label}`, { description: roleMeta[r].user.name });
    if (!canAccess(r, location.pathname)) navigate(roleMeta[r].home);
  };

  const group = (label: string, roles: Role[]) =>
  <div className="py-1">
      <p className="px-3 pb-1 pt-2 text-[11px] font-medium text-muted">{label}</p>
      {roles.map((r) =>
    <button
      key={r}
      onClick={() => choose(r)}
      className="flex w-full items-center gap-3 px-3 py-2 text-left transition-colors duration-150 hover:bg-surface-2">
      
          <span className="min-w-0 flex-1">
            <span className="block text-sm text-ink">{roleMeta[r].label}</span>
            <span className="block text-xs text-muted">
              {roleMeta[r].user.name} · {roleMeta[r].org}
            </span>
          </span>
          {r === role && <CheckIcon className="h-4 w-4 text-accent-ink" aria-label="Current role" />}
        </button>
    )}
    </div>;


  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="menu"
        aria-expanded={open}
        className="flex h-9 items-center gap-1.5 rounded-full border border-accent/30 bg-accent/10 pl-2.5 pr-2 text-[13px] font-medium text-accent-ink transition-colors duration-150 hover:bg-accent/15">
        
        <ShieldIcon className="h-3.5 w-3.5" aria-hidden />
        <span className="hidden md:inline">{roleMeta[role].label}</span>
        <span className="md:hidden">{roleMeta[role].short}</span>
        <ChevronDownIcon className={cn('h-3.5 w-3.5 transition-transform duration-150', open && 'rotate-180')} aria-hidden />
      </button>
      <DropdownPanel open={open} className="w-72 max-w-[calc(100vw-1.5rem)]">
        <div className="border-b border-line px-3 py-2.5">
          <p className="text-sm font-medium text-ink">Switch role</p>
          <p className="text-xs text-muted">Access to screens and actions follows the role</p>
        </div>
        <div className="max-h-[70vh] divide-y divide-line overflow-y-auto">
          {group('Portals', portalRoles)}
          {group('Internal roles', internalRoles)}
        </div>
      </DropdownPanel>
    </div>);

}