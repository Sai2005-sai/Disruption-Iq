import React from 'react';
import { MenuIcon, MoonIcon, SunIcon } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { GlobalSearch } from './GlobalSearch';
import { RoleSwitcher } from './RoleSwitcher';
import { NotificationsMenu } from './NotificationsMenu';
import { UserMenu } from './UserMenu';

export function TopBar({ onMenu }: {onMenu: () => void;}) {
  const { dark, toggleDark } = useApp();
  return (
    <header className="relative flex h-16 shrink-0 items-center gap-2 border-b border-line bg-surface px-3 sm:gap-3 sm:px-6">
      <button
        onClick={onMenu}
        className="rounded-lg p-2 text-ink-2 transition-colors duration-150 hover:bg-surface-2 lg:hidden"
        aria-label="Open navigation">
        
        <MenuIcon className="h-5 w-5" />
      </button>
      <GlobalSearch />
      <div className="ml-auto flex items-center gap-1 sm:gap-1.5">
        <RoleSwitcher />
        <button
          onClick={toggleDark}
          className="rounded-lg p-2 text-ink-2 transition-colors duration-150 hover:bg-surface-2 hover:text-ink"
          aria-label={dark ? 'Switch to light mode' : 'Switch to dark mode'}>
          
          {dark ? <SunIcon className="h-[18px] w-[18px]" /> : <MoonIcon className="h-[18px] w-[18px]" />}
        </button>
        <NotificationsMenu />
        <UserMenu />
      </div>
    </header>);

}