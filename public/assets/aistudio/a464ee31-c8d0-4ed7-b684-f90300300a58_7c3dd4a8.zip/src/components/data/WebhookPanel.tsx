import React, { useState } from 'react';
import { SendIcon, RotateCcwIcon } from 'lucide-react';
import { toast } from 'sonner';
import { webhookCarriers } from '../../data/dataConsole';
import { Card, CardHeader } from '../ui/Card';
import { Button } from '../ui/Button';
import { Field, inputClass } from '../ui/Field';

export interface LogEvent {
  id: string;
  time: string;
  kind: 'accepted' | 'duplicate' | 'scenario';
  title: string;
  detail: string;
}

interface Props {
  onEvent: (e: Omit<LogEvent, 'id' | 'time'>) => void;
}

const eventTypes = ['shipment.delayed', 'shipment.in_transit', 'shipment.exception', 'shipment.delivered'];

export function WebhookPanel({ onEvent }: Props) {
  const [carrier, setCarrier] = useState(webhookCarriers[1]);
  const [awb, setAwb] = useState('77812045');
  const [type, setType] = useState(eventTypes[0]);
  const [lastKey, setLastKey] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [seq, setSeq] = useState(1);

  const key = `idem_${carrier.toLowerCase().replace(/\s/g, '')}_${awb}_${String(seq).padStart(3, '0')}`;
  const payload = {
    event: type,
    carrier,
    awb,
    eta_delta_minutes: type === 'shipment.delayed' ? 540 : 0,
    location: 'Hosur hub',
    occurred_at: '2026-10-29T11:42:00+05:30',
    idempotency_key: key
  };

  const send = () => {
    if (!/^\d{6,12}$/.test(awb)) {
      toast.error('AWB must be 6–12 digits');
      return;
    }
    setSending(true);
    setTimeout(() => {
      onEvent({ kind: 'accepted', title: `202 Accepted · ${type}`, detail: `${carrier} AWB ${awb} · key ${key}` });
      setLastKey(key);
      setSeq((s) => s + 1);
      setSending(false);
      toast.success('Test webhook delivered', { description: `${type} · signature verified` });
    }, 600);
  };

  const replay = () => {
    if (!lastKey) return;
    onEvent({ kind: 'duplicate', title: '200 Duplicate ignored', detail: `Idempotency key ${lastKey} already processed — no state change` });
    toast('Duplicate webhook ignored', { description: 'Idempotency protection prevented double-processing' });
  };

  return (
    <Card as="section">
      <CardHeader title="Carrier webhook simulator" description="POST /webhooks/carrier · HMAC-SHA256 signed" />
      <div className="space-y-4 p-5">
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Carrier" htmlFor="wh-carrier">
            <select id="wh-carrier" value={carrier} onChange={(e) => setCarrier(e.target.value)} className={inputClass}>
              {webhookCarriers.map((c) =>
              <option key={c}>{c}</option>
              )}
            </select>
          </Field>
          <Field label="AWB" htmlFor="wh-awb">
            <input id="wh-awb" value={awb} onChange={(e) => setAwb(e.target.value)} className={inputClass} inputMode="numeric" />
          </Field>
          <Field label="Event" htmlFor="wh-type">
            <select id="wh-type" value={type} onChange={(e) => setType(e.target.value)} className={inputClass}>
              {eventTypes.map((t) =>
              <option key={t}>{t}</option>
              )}
            </select>
          </Field>
        </div>
        <pre className="max-h-48 overflow-auto rounded-lg bg-navy p-3 font-mono text-[12px] leading-relaxed text-slate-100">{JSON.stringify(payload, null, 2)}</pre>
        <div className="flex flex-wrap gap-2">
          <Button icon={<SendIcon className="h-4 w-4" />} loading={sending} onClick={send}>
            Send test webhook
          </Button>
          <Button variant="secondary" icon={<RotateCcwIcon className="h-4 w-4" />} disabled={!lastKey} onClick={replay}>
            Replay duplicate webhook
          </Button>
        </div>
      </div>
    </Card>);

}