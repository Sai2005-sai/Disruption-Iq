import React, { useRef, useState } from 'react';
import { UploadIcon, FileSpreadsheetIcon, FileWarningIcon, CheckIcon } from 'lucide-react';
import { toast } from 'sonner';
import { validationIssues, validationSummary, IssueType } from '../../data/dataConsole';
import { useApp } from '../../contexts/AppContext';
import { Card, CardHeader } from '../ui/Card';
import { Button } from '../ui/Button';
import { StatusChip, Tone } from '../ui/Badge';
import { Skeleton } from '../ui/Skeleton';
import { EmptyState } from '../ui/EmptyState';
import { Segmented } from '../ui/Tabs';
import { cn } from '../../utils/cn';

type Phase = {kind: 'idle';} | {kind: 'error';message: string;} | {kind: 'validating';name: string;} | {kind: 'report';name: string;committed: boolean;};
type IssueFilter = 'all' | IssueType;
const issueTone: Record<IssueType, Tone> = { invalid: 'danger', duplicate: 'warning', conflicting: 'orange' };

export function ImportPanel() {
  const { logAudit } = useApp();
  const [phase, setPhase] = useState<Phase>({ kind: 'idle' });
  const [dragging, setDragging] = useState(false);
  const [filter, setFilter] = useState<IssueFilter>('all');
  const fileRef = useRef<HTMLInputElement>(null);

  const handle = (name: string) => {
    if (!/\.(csv|json)$/i.test(name)) {
      setPhase({ kind: 'error', message: `“${name}” isn’t a CSV or JSON file.` });
      return;
    }
    setPhase({ kind: 'validating', name });
    setTimeout(() => setPhase({ kind: 'report', name, committed: false }), 1300);
  };

  const issues = validationIssues.filter((i) => filter === 'all' || i.type === filter);

  return (
    <Card as="section" className="min-w-0">
      <CardHeader title="Data import" description="Orders, shipments, stock or supplier records · CSV or JSON" />
      <div className="p-5">
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            const f = e.dataTransfer.files[0];
            if (f) handle(f.name);
          }}
          className={cn('flex flex-col items-center rounded-xl border-2 border-dashed px-4 py-8 text-center transition-colors duration-150', dragging ? 'border-accent bg-accent/5' : 'border-line')}>
          
          <UploadIcon className="h-6 w-6 text-muted" aria-hidden />
          <p className="mt-2 text-sm text-ink">
            Drop a file here or{' '}
            <button onClick={() => fileRef.current?.click()} className="font-medium text-accent-ink hover:underline">
              browse
            </button>
          </p>
          <p className="text-xs text-muted">.csv or .json · up to 20 MB</p>
          <input
            ref={fileRef}
            type="file"
            accept=".csv,.json"
            className="sr-only"
            aria-label="Choose import file"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handle(f.name);
              e.target.value = '';
            }} />
          
          <Button variant="ghost" size="sm" className="mt-3" icon={<FileSpreadsheetIcon className="h-4 w-4" />} onClick={() => handle('oms_orders_2026-10-29.csv')}>
            Use sample file
          </Button>
        </div>

        {phase.kind === 'error' &&
        <div className="mt-4">
            <EmptyState icon={FileWarningIcon} tone="error" title="Unsupported file" body={`${phase.message} Export your data as CSV (UTF-8) or JSON and try again.`} className="py-6" />
          </div>
        }

        {phase.kind === 'validating' &&
        <div className="mt-5 space-y-3" role="status" aria-label="Validating file">
            <p className="text-sm text-muted">Validating {phase.name}…</p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[0, 1, 2, 3].map((i) =>
            <Skeleton key={i} className="h-16" />
            )}
            </div>
            <Skeleton className="h-32" />
          </div>
        }

        {phase.kind === 'report' &&
        <div className="mt-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm font-medium text-ink">Validation report · {phase.name}</p>
              <span className="text-xs text-muted">1,197 rows checked</span>
            </div>
            <dl className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
            { k: 'Valid', v: validationSummary.valid.toLocaleString('en-IN'), c: 'text-risk-low-ink' },
            { k: 'Invalid', v: validationSummary.invalid, c: 'text-risk-critical-ink' },
            { k: 'Duplicate', v: validationSummary.duplicate, c: 'text-risk-moderate-ink' },
            { k: 'Conflicting', v: validationSummary.conflicting, c: 'text-risk-high-ink' }].
            map((s) =>
            <div key={s.k} className="rounded-lg bg-surface-2 px-3 py-2.5">
                  <dt className="text-xs text-muted">{s.k}</dt>
                  <dd className={cn('text-xl font-semibold tabular-nums', s.c)}>{s.v}</dd>
                </div>
            )}
            </dl>
            <div className="mt-4 overflow-x-auto">
              <Segmented<IssueFilter>
              label="Filter issues"
              value={filter}
              onChange={setFilter}
              options={[
              { id: 'all', label: 'All issues' },
              { id: 'invalid', label: 'Invalid' },
              { id: 'duplicate', label: 'Duplicate' },
              { id: 'conflicting', label: 'Conflicting' }]
              } />
            
            </div>
            <div className="mt-3 overflow-x-auto rounded-lg border border-line">
              <table className="w-full min-w-[520px] text-sm">
                <thead>
                  <tr className="border-b border-line bg-surface-2/60 text-left text-xs text-muted">
                    <th className="px-3 py-2 font-medium">Row</th>
                    <th className="px-3 py-2 font-medium">Record</th>
                    <th className="px-3 py-2 font-medium">Type</th>
                    <th className="px-3 py-2 font-medium">Reason</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {issues.map((i) =>
                <tr key={i.row}>
                      <td className="px-3 py-2.5 tabular-nums text-muted">{i.row}</td>
                      <td className="whitespace-nowrap px-3 py-2.5 font-medium text-ink">{i.record}</td>
                      <td className="px-3 py-2.5">
                        <StatusChip tone={issueTone[i.type]}>{i.type}</StatusChip>
                      </td>
                      <td className="px-3 py-2.5 text-ink-2">{i.reason}</td>
                    </tr>
                )}
                </tbody>
              </table>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button
              disabled={phase.committed}
              icon={phase.committed ? <CheckIcon className="h-4 w-4" /> : undefined}
              onClick={() => {
                setPhase({ ...phase, committed: true });
                logAudit({ action: 'Data update', target: phase.name, reason: 'Imported valid records; issues quarantined', after: '1,184 records committed · 13 quarantined' });
                toast.success('1,184 valid records imported', { description: '13 records quarantined for review' });
              }}>
              
                {phase.committed ? 'Imported' : 'Import 1,184 valid records'}
              </Button>
              <Button variant="ghost" onClick={() => setPhase({ kind: 'idle' })}>
                Discard
              </Button>
            </div>
          </div>
        }
      </div>
    </Card>);

}