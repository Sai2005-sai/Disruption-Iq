import React, { useEffect } from 'react';
import { MapContainer, TileLayer, CircleMarker, Tooltip, Polyline, useMap } from 'react-leaflet';
import { useApp } from '../../contexts/AppContext';
import { cn } from '../../utils/cn';

export interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  color: string;
  label: string;
  sublabel?: string;
  radius?: number;
  permanent?: boolean;
}

interface MapViewProps {
  markers: MapMarker[];
  center: [number, number];
  zoom: number;
  route?: [number, number][];
  routeColor?: string;
  selectedId?: string | null;
  onSelect?: (id: string) => void;
  fitBounds?: boolean;
  className?: string;
}

function ViewController({ center, zoom, bounds }: {center: [number, number];zoom: number;bounds: [number, number][] | null;}) {
  const map = useMap();
  const key = bounds ? JSON.stringify(bounds) : `${center[0]},${center[1]},${zoom}`;
  useEffect(() => {
    if (bounds && bounds.length > 1) map.fitBounds(bounds, { padding: [36, 36] });else
    map.setView(center, zoom, { animate: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  useEffect(() => {
    const el = map.getContainer();
    const ro = new ResizeObserver(() => map.invalidateSize());
    ro.observe(el);
    return () => ro.disconnect();
  }, [map]);
  return null;
}

export function MapView({ markers, center, zoom, route, routeColor = '#14B8A6', selectedId, onSelect, fitBounds, className }: MapViewProps) {
  const { dark } = useApp();
  const tiles = dark ?
  'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png' :
  'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png';
  const bounds = fitBounds ? markers.map((m) => [m.lat, m.lng] as [number, number]) : null;

  return (
    <div className={cn('relative isolate z-0 overflow-hidden rounded-xl border border-line', className)}>
      <MapContainer center={center} zoom={zoom} scrollWheelZoom={false} className="h-full w-full" attributionControl>
        <TileLayer key={tiles} url={tiles} attribution='&copy; OpenStreetMap &copy; CARTO' />
        <ViewController center={center} zoom={zoom} bounds={bounds} />
        {route && route.length > 1 && <Polyline positions={route} pathOptions={{ color: routeColor, weight: 3, opacity: 0.85, dashArray: '6 6' }} />}
        {markers.map((m) => {
          const selected = m.id === selectedId;
          return (
            <CircleMarker
              key={m.id}
              center={[m.lat, m.lng]}
              radius={selected ? (m.radius ?? 8) + 4 : m.radius ?? 8}
              pathOptions={{
                color: selected ? dark ? '#E2E8F0' : '#0F2A4A' : '#FFFFFF',
                weight: selected ? 3 : 2,
                fillColor: m.color,
                fillOpacity: 1
              }}
              eventHandlers={onSelect ? { click: () => onSelect(m.id) } : undefined}>
              
              <Tooltip direction="top" offset={[0, -8]} permanent={m.permanent}>
                <span className="font-medium">{m.label}</span>
                {m.sublabel && <span className="block text-[11px] opacity-70">{m.sublabel}</span>}
              </Tooltip>
            </CircleMarker>);

        })}
      </MapContainer>
    </div>);

}